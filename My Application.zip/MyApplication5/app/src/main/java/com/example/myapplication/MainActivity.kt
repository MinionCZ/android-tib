package com.example.myapplication

import android.graphics.Color
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.core.view.children

class MainActivity : AppCompatActivity() {
    var counter = 0
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var button = Button(applicationContext)
        var root = findViewById<LinearLayout>(R.id.root)
        root.addView(button)
        button.setOnClickListener {
            removeAllButtons()
        }
        root.addView(getStyledButton())


    }
    @RequiresApi(Build.VERSION_CODES.O)
    fun getStyledButton() : Button {
        var button = Button(applicationContext)
        button.text = "Click me $counter"
        button.setBackgroundColor(Color.rgb(100.0f, 50.0f, 80.0f))
        button.setOnClickListener {
            counter++
            var root = findViewById<LinearLayout>(R.id.root)
            root.addView(getStyledButton())
        }
        return button
    }
    @RequiresApi(Build.VERSION_CODES.O)
    fun removeAllButtons(){
        var root = findViewById<LinearLayout>(R.id.root)
        root.removeAllViews()
        var button = Button(applicationContext)
        button.setOnClickListener {
            removeAllButtons()
        }
        root.addView(button)
        root.addView(getStyledButton())
    }


}