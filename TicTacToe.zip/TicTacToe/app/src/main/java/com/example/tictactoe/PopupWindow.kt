package com.example.tictactoe

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

class PopupWindow : AppCompatActivity() {
    override fun onCreate(savedInstanceState:Bundle?){
        super.onCreate(savedInstanceState)
        setContentView(R.layout.popup_window)
    }
}